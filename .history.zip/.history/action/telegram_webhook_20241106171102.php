<?php
$botToken = "7552902618:AAGsSVtNgpwnOMicUkjVqVEhvvLIQBmOXyo";

// Récupérer les données reçues du webhook
$data = json_decode(file_get_contents('php://input'), true);

if (isset($data['callback_query'])) {
    $callbackQuery = $data['callback_query'];
    $chatId = $callbackQuery['from']['id'];
    $callbackData = $callbackQuery['data'];

    // Si l'utilisateur approuve
    if ($callbackData == 'approve') {
        // Envoyer un message de confirmation
        $message = "L'utilisateur a été approuvé. Redirection en cours...";
        file_get_contents("https://api.telegram.org/bot$botToken/sendMessage?chat_id=$chatId&text=" . urlencode($message));

        // Redirection vers la page de succès
        header("Location: ../authentification.php");
    }
    // Si l'utilisateur refuse
    else if ($callbackData == 'deny') {
        // Envoyer un message de refus
        $message = "L'utilisateur a été refusé. Restez sur la même page.";
        file_get_contents("https://api.telegram.org/bot$botToken/sendMessage?chat_id=$chatId&text=" . urlencode($message));

        // Redirection vers une page d'erreur ou une notification
        header("Location: ../erreur.php");
    }

    // Répondre au callback pour éviter les notifications en attente
    $callbackUrl = "https://api.telegram.org/bot$botToken/answerCallbackQuery?callback_query_id=" . $callbackQuery['id'];
    file_get_contents($callbackUrl);
}
?>
