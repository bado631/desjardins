<?php
// telegram_api.php

function sendToTelegram($message) {
    $telegramToken = 'VOTRE_TOKEN_TELEGRAM'; // Remplacez par le token de votre bot Telegram
    $chatID = 'VOTRE_CHAT_ID'; // Remplacez par l'ID de votre chat

    $url = "https://api.telegram.org/bot$telegramToken/sendMessage";
    $data = [
        'chat_id' => $chatID,
        'text' => $message,
        'parse_mode' => 'HTML' // Optionnel : formatage HTML
    ];

    // Initialiser cURL pour envoyer la requête
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    
    // Exécuter la requête et gérer les erreurs
    $response = curl_exec($ch);
    if (curl_errno($ch)) {
        echo 'Erreur cURL : ' . curl_error($ch);
    }
    curl_close($ch);

    return $response;
}
?>
